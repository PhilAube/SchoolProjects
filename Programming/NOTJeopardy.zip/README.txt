===================================================================================================

NOT JEOPARDY - README

===================================================================================================

HOW TO PLAY / GAME INSTRUCTIONS

It’s up to the players to decide who goes first to pick a question.
Why not a game of rock paper scissors?
It's also up to the users to keep track of whose turn it is.

When a player picks a question...
Both teams have 30 seconds to hit the buzzer if they think they know the answer.

The buzzer buttons are Left Shift for Player 1, and Right Shift for Player 2.
If nobody hits the buzzer after 30 seconds, the answer is shown and no scores are changed.

If both players hit the buzzer within the 30 seconds, the first to buzz gets to answer first.
They player that buzzed first then needs to tell the other player what their answer is.
If the second player also hit their buzzer, they share their answer afterwards.

Once ready, the players click “Show Answer” to reveal the answer.
If the first to buzz got the question right, click the appropriate button to add to their points.
If their answer was wrong, click the appropriate button to deduct their points.
If the second player buzzed too, click the appropriate button based on their right/wrong answer.

At the end of the game when all questions are chosen, the winner is the one with the higher score.

===================================================================================================

SETUP:

Start by extracting the EXE and MSI files to the same folder on your computer.
Once extracted, run setup.exe and follow all of the installation wizard's 
instructions. Once complete, you can play the game from the desktop shortcut.

===================================================================================================

Developed by Phil Aube & Aiden Eves (AKA Null), 2020

===================================================================================================