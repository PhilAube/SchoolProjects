===============================================================================

TIMEWASTER 1.0 - README

===============================================================================

SYSTEM REQUIREMENTS:

This game should run without any issues on modern systems with Windows.
Not all screen resolutions are supported, so if the game crashes upon
launching, please consider increasing your screen resolution and try again.

If the game still crashes regardless, I'm sorry about that.
The reality is, this was my first game and I wasn't the best programmer then.
As a result, the code sucks and I refuse to maintain it anymore.

If you really want to play this game, consider trying TimeWaster 2! 
I fixed pretty much everything that sucked about this version.
The sequel is playable on my website, and doesn't require any installation!

===============================================================================

SETUP:

Start by extracting the EXE and MSI files to the same folder on your computer.
Once extracted, run setup.exe and follow all of the installation wizard's 
instructions. Once complete, you can play the game from the desktop shortcut.

===============================================================================

Developed by Phil Aube, 2019 - 2021

===============================================================================
